// Section 2 — TRAJECTOIRE CO2: "La trace inéluctable"

function Trajectory() {
  const [ref, , seen] = useInView({ threshold: 0.15 });
  const [overlay, setOverlay] = useState('linear'); // linear | quad | cubic
  const [hoverIdx, setHoverIdx] = useState(null);
  const [pickedEvent, setPickedEvent] = useState(null);

  const series = window.CO2_ANNUAL; // 47 points
  const monthly = window.CO2_SERIES; // 564 points

  const W = 760, H = 360;
  const padL = 56, padR = 24, padT = 24, padB = 36;
  const yMin = 332, yMax = 432;
  const xToY = (year) => padT + ((1 - (year - 1979) / 46) * 0) + 0; // unused
  const sx = (year) => padL + ((year - 1979) / 46) * (W - padL - padR);
  const sy = (v) => padT + (1 - (v - yMin) / (yMax - yMin)) * (H - padT - padB);

  // Main CO2 path
  const mainPath = useMemo(() => {
    return monthly.map((d, i) => `${i === 0 ? 'M' : 'L'}${sx(d.year).toFixed(1)},${sy(d.value).toFixed(1)}`).join(' ');
  }, []);

  // IC95 band: ± uncertainty from sen
  const senLoLine = useMemo(() => {
    const start = 336.78;
    const data = [];
    for (let y = 0; y < 47; y++) {
      const lo = start + 1.777 * y;
      const hi = start + 1.965 * y + 0.0001 * 12 * y * y; // rough
      data.push({ year: 1979 + y, lo, hi });
    }
    return data;
  }, []);
  const bandPath = useMemo(() => {
    const up = senLoLine.map(d => `${sx(d.year).toFixed(1)},${sy(d.hi).toFixed(1)}`).join(' L');
    const dn = senLoLine.slice().reverse().map(d => `${sx(d.year).toFixed(1)},${sy(d.lo).toFixed(1)}`).join(' L');
    return `M${up} L${dn} Z`;
  }, []);

  // Overlay paths
  const overlayPaths = useMemo(() => {
    const linear = [], quad = [], cubic = [];
    const start = 336.78;
    for (let y = 0; y <= 46; y += 0.25) {
      const t = y;
      linear.push([1979 + y, start + 1.881 * t]);
      quad.push([1979 + y, start + 1.78 * t + 0.003 * t * t]);
      cubic.push([1979 + y, start + 1.55 * t + 0.005 * t * t + 0.000015 * t * t * t]);
    }
    const toPath = (arr) => arr.map(([y, v], i) => `${i === 0 ? 'M' : 'L'}${sx(y).toFixed(1)},${sy(v).toFixed(1)}`).join(' ');
    return { linear: toPath(linear), quad: toPath(quad), cubic: toPath(cubic) };
  }, []);

  // Hover scrub
  const svgRef = useRef(null);
  const onSvgMove = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const realX = (x / rect.width) * W;
    const year = 1979 + ((realX - padL) / (W - padL - padR)) * 46;
    const idx = Math.max(0, Math.min(monthly.length - 1, Math.round((year - 1979) * 12)));
    setHoverIdx(idx);
  };
  const onSvgLeave = () => setHoverIdx(null);

  const hoverData = hoverIdx != null ? monthly[hoverIdx] : null;

  const events = window.EVENTS;

  return (
    <section ref={ref} className="section" id="sec-2" data-screen-label="02 Trajectory">
      <div className="aurora" />
      <SectionHeader
        act="02"
        kicker="La trace inéluctable"
        title="Une pente <span class='text-hot'>quasi linéaire</span>. <br/>Une accélération qui se confirme."
        accent="var(--hot1)"
      />

      <div style={{ position: 'relative', zIndex: 2, display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 24, alignItems: 'start' }}>
        {/* Left: chart */}
        <div className="glass" style={{ padding: 24, position: 'relative' }}>
          <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase' }}>CO₂ atmosphérique · Mauna Loa-style</div>
              <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>1979 → 2025 · données mensuelles, série annuelle moyennée</div>
            </div>
            <div className="hstack" style={{ gap: 6 }}>
              {['linear','quad','cubic'].map(o => (
                <button key={o} className={`btn-glass ${overlay === o ? 'active' : ''}`} onClick={() => setOverlay(o)}>
                  {o === 'linear' ? 'Linéaire' : o === 'quad' ? 'Quadratique' : 'Cubique'}
                </button>
              ))}
            </div>
          </div>

          <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto', display: 'block' }}
               onMouseMove={onSvgMove} onMouseLeave={onSvgLeave}>
            <defs>
              <linearGradient id="co2grad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#00D9FF" />
                <stop offset="55%" stopColor="#FFB627" />
                <stop offset="100%" stopColor="#FF6B35" />
              </linearGradient>
              <linearGradient id="co2fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FF6B35" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#FF6B35" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Y axis ticks */}
            {[340, 360, 380, 400, 420].map(v => (
              <g key={v}>
                <line x1={padL} x2={W - padR} y1={sy(v)} y2={sy(v)} stroke="rgba(255,255,255,0.06)" strokeDasharray="2 4" />
                <text x={padL - 8} y={sy(v) + 3} textAnchor="end" className="mono" fontSize="10" fill="#9CA3AF">{v}</text>
              </g>
            ))}
            {/* X axis */}
            {[1980, 1990, 2000, 2010, 2020, 2025].map(y => (
              <g key={y}>
                <text x={sx(y)} y={H - 12} textAnchor="middle" className="mono" fontSize="10" fill="#9CA3AF">{y}</text>
              </g>
            ))}
            <text x={padL - 8} y={padT + 4} textAnchor="end" className="mono" fontSize="9" fill="#9CA3AF">ppm</text>

            {/* IC band */}
            <path d={bandPath} fill="rgba(255, 182, 39, 0.10)" />

            {/* Overlay regression */}
            <path d={overlayPaths[overlay]} stroke={overlay === 'linear' ? '#FFB627' : overlay === 'quad' ? '#F7931E' : '#FF6B35'}
                  strokeWidth="1.4" strokeDasharray="6 4" fill="none" opacity="0.7" />

            {/* Main curve */}
            <path d={mainPath} stroke="url(#co2grad)" strokeWidth="1.8" fill="none" />

            {/* Events */}
            {events.map((ev, i) => (
              <g key={i} onClick={() => setPickedEvent(ev)} style={{ cursor: 'pointer' }}>
                <line x1={sx(ev.year)} x2={sx(ev.year)} y1={padT} y2={H - padB} stroke={ev.color} strokeOpacity="0.18" strokeDasharray="2 3" />
                <circle cx={sx(ev.year)} cy={H - padB + 14} r="3.5" fill={ev.color} />
              </g>
            ))}

            {/* Hover scrub */}
            {hoverData && (
              <g>
                <line x1={sx(hoverData.year)} x2={sx(hoverData.year)} y1={padT} y2={H - padB} stroke="#fff" strokeOpacity="0.3" />
                <circle cx={sx(hoverData.year)} cy={sy(hoverData.value)} r="4" fill="#fff" />
              </g>
            )}
          </svg>

          {/* Hover tooltip */}
          {hoverData && (
            <div className="glass" style={{
              position: 'absolute',
              left: `${(sx(hoverData.year) / W) * 100}%`,
              top: 60,
              transform: 'translateX(12px)',
              padding: '10px 14px', fontSize: 12,
              pointerEvents: 'none', zIndex: 4,
            }}>
              <div className="mono" style={{ color: 'var(--text-dim)', fontSize: 10 }}>{Math.floor(hoverData.year)} · M{(hoverData.month + 1).toString().padStart(2, '0')}</div>
              <div className="display tabular" style={{ fontSize: 22, color: 'var(--hot1)' }}>{hoverData.value.toFixed(2)}</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)' }}>ppm CO₂</div>
            </div>
          )}

          {/* Legend */}
          <div className="hstack" style={{ marginTop: 12, gap: 18, fontSize: 11, color: 'var(--text-dim)' }}>
            <span className="hstack" style={{ gap: 6 }}>
              <span style={{ width: 12, height: 2, background: 'linear-gradient(to right, #00D9FF, #FF6B35)' }}></span>
              Mensuel
            </span>
            <span className="hstack" style={{ gap: 6 }}>
              <span style={{ width: 12, height: 2, background: '#FFB627', boxShadow: '0 0 0 1px #FFB627' }}></span>
              IC 95% Sen
            </span>
            <span className="hstack" style={{ gap: 6 }}>
              <span style={{ width: 12, height: 0, borderTop: '1.4px dashed #FF6B35' }}></span>
              Modèle {overlay}
            </span>
          </div>
        </div>

        {/* Right: metric cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <MetricCard
            label="Pente Sen (robuste)"
            value="+1.881"
            unit="ppm/an"
            sub={<>IC 95% bootstrap : <span className="mono text-hot">[1.78, 1.97]</span></>}
            spark={series.map(d => d.value)}
            accent="var(--hot1)"
          />
          <MetricCard
            label="Modèle exponentiel"
            value="0.5%"
            unit="/an"
            sub={<>Taux croissance instantané · doublement à <span className="mono text-hot">137 ans</span></>}
            accent="var(--hot2)"
          />
          <div className="glass" style={{ padding: 22 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.14em' }}>Vs. paléoclimat (Vostok)</div>
            <div className="hstack" style={{ gap: 10, alignItems: 'baseline', marginTop: 8 }}>
              <span className="display tabular" style={{ fontSize: 40, color: 'var(--green)', lineHeight: 1 }}>30×</span>
              <span className="mono" style={{ fontSize: 12, color: 'var(--text-dim)' }}>plus rapide</span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-dim)', marginTop: 8 }}>
              Le taux moderne dépasse le pic paléoclimatique enregistré dans la
              carotte de Vostok (414 ka).
            </div>
            {/* Mini paléo viz */}
            <svg viewBox="0 0 220 50" style={{ width: '100%', marginTop: 10 }}>
              {window.VOSTOK_SAMPLE.slice().reverse().map((d, i, arr) => {
                const x = (1 - d.ageBP / 420000) * 200 + 5;
                const y = 50 - ((d.CO2 - 180) / 245) * 40;
                return <circle key={i} cx={x} cy={y} r="1.6" fill="#52FFB8" />;
              })}
              {/* present-day arrow */}
              <line x1="205" y1="48" x2="205" y2="2" stroke="#FF6B35" strokeWidth="1.4" />
              <polygon points="202,4 208,4 205,0" fill="#FF6B35" />
              <text x="195" y="44" textAnchor="end" fontSize="7" fontFamily="JetBrains Mono" fill="#9CA3AF">414 ka</text>
              <text x="207" y="44" textAnchor="start" fontSize="7" fontFamily="JetBrains Mono" fill="#FF6B35">2025</text>
            </svg>
          </div>
        </div>
      </div>

      {/* Timeline events */}
      <div style={{ marginTop: 40, position: 'relative', zIndex: 2 }}>
        <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 16 }}>
          Événements marquants
        </div>
        <div className="glass" style={{ padding: '22px 28px', position: 'relative' }}>
          <div style={{ position: 'relative', height: 60 }}>
            <div style={{ position: 'absolute', top: 28, left: 12, right: 12, height: 1, background: 'rgba(255,255,255,0.12)' }} />
            {[1980, 1990, 2000, 2010, 2020].map(y => {
              const t = (y - 1979) / 46;
              return (
                <div key={y} style={{ position: 'absolute', left: `calc(12px + ${t * 100}% - ${t * 24}px)`, top: 36, fontSize: 10, color: 'var(--text-dim)', fontFamily: 'JetBrains Mono', transform: 'translateX(-50%)' }}>
                  {y}
                </div>
              );
            })}
            {events.map((ev, i) => {
              const t = (ev.year - 1979) / 46;
              const isPicked = pickedEvent && pickedEvent.name === ev.name;
              return (
                <button key={i}
                  onClick={() => setPickedEvent(isPicked ? null : ev)}
                  style={{
                    position: 'absolute', left: `calc(12px + ${t * 100}% - ${t * 24}px)`, top: 18,
                    transform: 'translateX(-50%)',
                    width: 22, height: 22, borderRadius: '50%',
                    background: isPicked ? ev.color : 'transparent',
                    border: `1.5px solid ${ev.color}`,
                    cursor: 'pointer',
                    padding: 0,
                    transition: 'all 280ms var(--ease-expo)',
                    boxShadow: isPicked ? `0 0 0 6px ${ev.color}22` : 'none',
                  }}
                  title={ev.name}
                />
              );
            })}
          </div>
          {pickedEvent && (
            <div style={{ marginTop: 18, padding: '16px 18px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)' }}>
              <div className="hstack" style={{ gap: 12, alignItems: 'baseline', marginBottom: 6 }}>
                <span className="display" style={{ fontSize: 22, color: pickedEvent.color }}>{pickedEvent.name}</span>
                <span className="mono" style={{ fontSize: 11, color: 'var(--text-dim)' }}>· {Math.floor(pickedEvent.year)}</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>{pickedEvent.desc}</div>
            </div>
          )}
          {!pickedEvent && (
            <div style={{ marginTop: 14, fontSize: 12, color: 'var(--text-dim)' }}>
              Cliquez un marqueur pour détailler.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

window.Trajectory = Trajectory;
