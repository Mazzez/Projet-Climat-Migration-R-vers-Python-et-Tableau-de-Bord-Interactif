// Section 4 — LE LIEN CLIMAT ↔ CO2: "Qui cause qui ?"

function ClimateCO2Link() {
  const [ref, , seen] = useInView({ threshold: 0.15 });
  const [repr, setRepr] = useState('rResid');
  const vars = window.ALL_VARS_FULL;

  const reprs = [
    { key: 'rLevel', label: 'Niveaux bruts',
      desc: 'Niveaux non transformés. Dominés par la trend commune entre CO₂ et la plupart des variables. Beaucoup de corrélations spurieuses, peu interprétables.' },
    { key: 'rAnom', label: 'Anomalies',
      desc: 'Cycle saisonnier retiré, mais la trend de long terme reste. Encore confondu par la dérive partagée — utile pour visualiser le climat sans bruit annuel.' },
    { key: 'rResid', label: 'Résidus (détendrés)',
      desc: 'Signal interannuel propre, sans la trend commune. C’est le test rigoureux du couplage climat ↔ CO₂. La plupart des liens ici sont causaux.' },
    { key: 'rD1', label: 'Δ 1 mois',
      desc: 'Différences mois-à-mois. Met en avant les chocs rapides (volcans, ENSO). Bruit élevé, signal de court terme.' },
    { key: 'rD12', label: 'Δ 12 mois',
      desc: 'Anomalies annuelles glissantes. Retire l’effet saisonnier ET la trend basse fréquence. Plus exigeant que les résidus.' },
  ];
  const reprObj = reprs.find(r => r.key === repr);

  // Heatmap: 21 vars × 5 reprs as a 3D-feeling bar grid
  // For the focused repr, show bars with height = |r|, color = sign.

  // Granger Sankey data
  const grangerGroups = {
    'X -> CO2': [], 'CO2 -> X': [], 'bidirectionnel': [], 'aucun': [],
  };
  vars.forEach(v => { grangerGroups[v.sens].push(v); });
  const groupColors = {
    'X -> CO2': '#52FFB8',
    'CO2 -> X': '#00D9FF',
    'bidirectionnel': '#FF6B35',
    'aucun': 'rgba(255,255,255,0.3)',
  };

  return (
    <section ref={ref} className="section" id="sec-4" data-screen-label="04 Link" style={{ background: 'radial-gradient(80% 60% at 50% 50%, rgba(0,217,255,0.03), transparent), var(--bg)' }}>
      <SectionHeader
        act="04"
        kicker="Qui cause qui ?"
        title='Sur <span class="text-cold">15 variables sur 21</span>, le climat précède le CO₂. <br/>Ce n’est pas une rétroaction. C’est une <span class="text-hot">empreinte humaine</span>.'
        accent="var(--green)"
      />

      {/* Big number with Granger summary */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 56, position: 'relative', zIndex: 2 }}>
        <div className="glass" style={{ padding: '36px 40px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.16em', color: 'var(--text-dim)', textTransform: 'uppercase' }}>
            Granger global — lag 6 mois
          </div>
          <div style={{ marginTop: 18, display: 'flex', alignItems: 'baseline', gap: 16 }}>
            <span className="display tabular" style={{ fontSize: 140, lineHeight: 0.9, color: 'var(--green)', letterSpacing: '-0.04em' }}>
              <CountUp value={15} duration={1800} />
            </span>
            <span className="mono" style={{ fontSize: 32, color: 'var(--text-dim)' }}>/ 21</span>
          </div>
          <div style={{ marginTop: 8, fontSize: 18, color: 'var(--text)', maxWidth: 480 }}>
            variables climatiques <span className="text-green">précèdent</span> le CO₂ atmosphérique avec une significativité statistique (<span className="mono">p &lt; 0.05</span>).
          </div>
          <div className="hstack" style={{ gap: 14, marginTop: 24, flexWrap: 'wrap' }}>
            <div className="pill pill-x">15 X → CO₂</div>
            <div className="pill pill-c">8 CO₂ → X</div>
            <div className="pill pill-bi">5 bidir.</div>
            <div className="pill pill-none">3 aucun</div>
          </div>
        </div>

        <div className="glass" style={{ padding: '36px 40px' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.16em', color: 'var(--text-dim)', textTransform: 'uppercase' }}>
            Modèle multivarié sur résidus
          </div>
          <div style={{ marginTop: 18, display: 'flex', alignItems: 'baseline', gap: 16 }}>
            <span className="display tabular" style={{ fontSize: 100, lineHeight: 0.9, color: 'var(--hot1)', letterSpacing: '-0.04em' }}>R²=<CountUp value={0.748} decimals={3} duration={1800} /></span>
          </div>
          <div style={{ marginTop: 12, fontSize: 15, color: 'var(--text-dim)' }}>
            12 variables climatiques résiduelles expliquent <strong className="text-hot">~75%</strong> du
            CO₂ résiduel — robuste à la dé-trend, et à l’autocorrélation (Newey-West).
          </div>
          <div className="divider" style={{ margin: '20px 0' }} />
          <div className="hstack" style={{ gap: 28 }}>
            <div>
              <div className="mono text-dim" style={{ fontSize: 10, letterSpacing: '0.1em' }}>CSDLF</div>
              <div className="mono tabular" style={{ fontSize: 22, color: 'var(--hot1)' }}>+7.84</div>
              <div className="mono text-dim" style={{ fontSize: 10 }}>W/m² · 47 ans</div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-dim)', maxWidth: 220 }}>
              Le LW descendant ciel clair (signature directe des GES) monte de
              <strong className="text-hot"> +7.84 W/m²</strong>. C’est <em>la</em> preuve physique.
            </div>
          </div>
        </div>
      </div>

      {/* Heatmap + repr selector */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.7fr 1fr', gap: 32, marginBottom: 56, position: 'relative', zIndex: 2, alignItems: 'start' }}>
        <div className="glass" style={{ padding: 24, overflow: 'hidden' }}>
          <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Corrélation Pearson · climat ↔ CO₂</div>
              <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>21 variables × 5 représentations · saturation = |r|</div>
            </div>
          </div>
          <Heatmap vars={vars} repr={repr} reprs={reprs} setRepr={setRepr} />
        </div>

        <div className="glass" style={{ padding: 24, position: 'sticky', top: 80 }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 12 }}>
            Pédagogie — {reprObj.label}
          </div>
          <div className="display" style={{ fontSize: 32, color: 'var(--cold1)', marginBottom: 12 }}>
            {repr === 'rResid' && '🎯'}
            {reprObj.label}
          </div>
          <div style={{ fontSize: 14, color: 'var(--text-dim)', lineHeight: 1.55, marginBottom: 16 }}>
            {reprObj.desc}
          </div>
          <div className="divider" style={{ margin: '16px 0' }} />
          <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 10 }}>Top 5 absolu</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {vars.slice().sort((a, b) => Math.abs(b[repr]) - Math.abs(a[repr])).slice(0, 5).map(v => (
              <div key={v.var} className="hstack" style={{ justifyContent: 'space-between', fontSize: 12 }}>
                <span className="mono" style={{ color: 'var(--text)' }}>{v.var}</span>
                <span className="mono tabular" style={{ color: v[repr] > 0 ? 'var(--hot1)' : 'var(--cold1)' }}>{v[repr] > 0 ? '+' : ''}{v[repr].toFixed(3)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sankey */}
      <div className="glass" style={{ padding: 28, position: 'relative', zIndex: 2 }}>
        <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Causalité de Granger · global · lag 6 mois</div>
            <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>Chaque variable est classée dans <strong>une</strong> des 4 catégories selon le test bidirectionnel.</div>
          </div>
        </div>
        <Sankey grangerGroups={grangerGroups} groupColors={groupColors} />
      </div>
    </section>
  );
}

// ----- Heatmap -----
function Heatmap({ vars, repr, reprs, setRepr }) {
  const cellW = 56;
  const cellH = 28;
  const labelW = 84;
  const reprKeys = reprs.map(r => r.key);
  return (
    <div style={{ position: 'relative', overflow: 'visible' }}>
      {/* Header row: representations */}
      <div className="hstack" style={{ gap: 2, marginLeft: labelW, marginBottom: 6 }}>
        {reprs.map(r => (
          <button key={r.key}
            onClick={() => setRepr(r.key)}
            className={`btn-glass ${repr === r.key ? 'active' : ''}`}
            style={{ width: cellW, padding: '6px 4px', fontSize: 10 }}>
            {r.label.split(' ')[0]}
          </button>
        ))}
      </div>

      {/* Sorted by current repr's |r| */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {vars.slice().sort((a, b) => Math.abs(b[repr]) - Math.abs(a[repr])).map(v => (
          <div key={v.var} className="hstack" style={{ gap: 2, height: cellH }}>
            <div style={{
              width: labelW, paddingRight: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11,
            }}>
              <span style={{ color: 'var(--text)' }}>{v.var}</span>
              <SensPill sens={v.sens} />
            </div>
            {reprKeys.map(rk => {
              const val = v[rk];
              const abs = Math.abs(val);
              const color = divergentColor(val, 0.7);
              const isActive = rk === repr;
              return (
                <div key={rk}
                  title={`${v.var} · ${rk} · r=${val.toFixed(3)}`}
                  onClick={() => setRepr(rk)}
                  style={{
                    width: cellW, height: cellH,
                    background: color,
                    opacity: 0.18 + abs * 0.82,
                    borderRadius: 3,
                    cursor: 'pointer',
                    transition: 'all 360ms var(--ease-expo)',
                    outline: isActive ? '1.5px solid rgba(255,255,255,0.7)' : 'none',
                    outlineOffset: isActive ? -2 : 0,
                    transform: isActive ? 'scale(1.04)' : 'scale(1)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: 9,
                    color: abs > 0.4 ? '#000' : 'rgba(255,255,255,0.55)',
                    fontVariantNumeric: 'tabular-nums',
                  }}>
                  {val.toFixed(2)}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ----- Sankey -----
function Sankey({ grangerGroups, groupColors }) {
  const W = 1100, H = 540;
  const leftX = 60, rightX = W - 200;
  const vars = window.ALL_VARS_FULL;
  const N = vars.length;
  const rowH = (H - 40) / N;
  // assign y per var on left
  const leftY = {};
  vars.forEach((v, i) => { leftY[v.var] = 20 + i * rowH + rowH / 2; });

  // right groups
  const groupOrder = ['X -> CO2', 'CO2 -> X', 'bidirectionnel', 'aucun'];
  const groupHeights = {};
  let totalY = 20;
  const groupY = {};
  groupOrder.forEach(g => {
    const items = grangerGroups[g];
    const h = items.length * rowH;
    groupHeights[g] = h;
    groupY[g] = totalY + h / 2;
    totalY += h + 12;
  });
  const totalUsed = totalY - 12;
  const offY = (H - totalUsed) / 2 - 20;
  Object.keys(groupY).forEach(k => groupY[k] += offY);

  // per-var y on right within group
  const rightY = {};
  groupOrder.forEach(g => {
    const items = grangerGroups[g];
    items.forEach((v, i) => {
      rightY[v.var] = groupY[g] - (groupHeights[g] / 2) + i * rowH + rowH / 2;
    });
  });

  // path: cubic bezier from (leftX, leftY) → (rightX, rightY)
  const link = (x1, y1, x2, y2) => {
    const cx1 = x1 + (x2 - x1) * 0.5;
    const cx2 = x2 - (x2 - x1) * 0.5;
    return `M${x1},${y1} C${cx1},${y1} ${cx2},${y2} ${x2},${y2}`;
  };

  const [hoverVar, setHoverVar] = useState(null);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <defs>
        {Object.entries(groupColors).map(([g, c]) => (
          <linearGradient key={g} id={`sg-${g.replace(/[^a-z]/gi, '')}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.08" />
            <stop offset="100%" stopColor={c} stopOpacity="0.45" />
          </linearGradient>
        ))}
      </defs>

      {/* Links */}
      {vars.map(v => {
        const c = groupColors[v.sens];
        const gradId = `sg-${v.sens.replace(/[^a-z]/gi, '')}`;
        const isHover = hoverVar === v.var;
        return (
          <g key={v.var}>
            <path
              d={link(leftX + 6, leftY[v.var], rightX - 6, rightY[v.var])}
              stroke={isHover ? c : `url(#${gradId})`}
              strokeWidth={isHover ? 4 : 2}
              fill="none"
              strokeOpacity={isHover ? 1 : (hoverVar ? 0.15 : 0.55)}
              style={{ transition: 'all 280ms var(--ease-expo)' }}
            />
          </g>
        );
      })}

      {/* Left labels */}
      {vars.map(v => (
        <g key={v.var}
          onMouseEnter={() => setHoverVar(v.var)}
          onMouseLeave={() => setHoverVar(null)}
          style={{ cursor: 'pointer' }}>
          <rect x={leftX - 56} y={leftY[v.var] - 9} width={62} height={18} rx={3}
            fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.08)" />
          <text x={leftX - 25} y={leftY[v.var] + 4} textAnchor="middle"
            fontSize="11" fontFamily="JetBrains Mono" fill={hoverVar === v.var ? groupColors[v.sens] : '#F5F5F7'}
            style={{ transition: 'fill 200ms' }}>
            {v.var}
          </text>
          <circle cx={leftX + 6} cy={leftY[v.var]} r="2.5" fill={groupColors[v.sens]} />
        </g>
      ))}

      {/* Right groups */}
      {groupOrder.map(g => {
        const c = groupColors[g];
        const items = grangerGroups[g];
        return (
          <g key={g}>
            <rect x={rightX} y={groupY[g] - groupHeights[g]/2 - 4}
              width={170} height={groupHeights[g] + 8} rx={6}
              fill={c} fillOpacity="0.08" stroke={c} strokeOpacity="0.3" />
            <text x={rightX + 14} y={groupY[g] - groupHeights[g]/2 + 16}
              fontSize="11" fontFamily="JetBrains Mono" fill={c}
              fontWeight="600" style={{ textTransform: 'uppercase' }}>
              {g.replace('->', '→')}
            </text>
            <text x={rightX + 156} y={groupY[g] - groupHeights[g]/2 + 16}
              textAnchor="end" fontSize="20" fontFamily="Space Grotesk" fill={c}
              fontWeight="600">
              {items.length}
            </text>
            {items.map((v, i) => (
              <text key={v.var}
                x={rightX + 14}
                y={groupY[g] - groupHeights[g]/2 + 34 + i * rowH + rowH / 2 + 1}
                fontSize="10" fontFamily="JetBrains Mono"
                fill={hoverVar === v.var ? c : 'rgba(245,245,247,0.6)'}
                onMouseEnter={() => setHoverVar(v.var)}
                onMouseLeave={() => setHoverVar(null)}
                style={{ cursor: 'pointer', transition: 'fill 200ms' }}>
                {v.var}
              </text>
            ))}
          </g>
        );
      })}
    </svg>
  );
}

window.ClimateCO2Link = ClimateCO2Link;
