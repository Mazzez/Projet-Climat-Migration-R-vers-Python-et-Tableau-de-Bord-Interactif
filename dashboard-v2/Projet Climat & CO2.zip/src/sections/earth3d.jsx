// Section 3 — TERRE 3D INTERACTIVE: "La carte du climat" (CENTERPIECE)

function Earth3D() {
  const [ref, , seen] = useInView({ threshold: 0.1 });
  const tw = useContext(window.TweaksContext) || {};
  const trendStrength = tw.trendStrength ?? 1.0;
  const bigSegments = tw.bigSegments ?? 128;
  const bigDistance = tw.bigDistance ?? 2.4;
  const [variable, setVariable] = useState('T2m');
  const [mode, setMode] = useState('sen'); // 'sen' | 'corr'
  const [year, setYear] = useState(2025);
  const [activeBands, setActiveBands] = useState(['boreal', 'tropical', 'austral']);
  const [picked, setPicked] = useState(null);
  const [showHotspots, setShowHotspots] = useState(true);

  const allVars = window.ALL_VARS_FULL;
  const hotspots = window.HOTSPOTS;

  // Build a derived grid based on variable + mode + year:
  // - For T2m + sen + 2025 → use real T2M_TREND_GRID.
  // - For other variables/modes → scale the grid by relative factor (clearly noted as visualization).
  const grid = useMemo(() => {
    const base = window.T2M_TREND_GRID;
    const v = allVars.find(x => x.var === variable) || allVars[0];
    let factor = 1;
    if (mode === 'sen') {
      // For non-T2m, scale magnitude based on relative |rResid| ratio (rough)
      if (variable !== 'T2m') {
        factor = (Math.abs(v.rResid) / 0.233) * 0.8;
      }
    } else {
      // corr mode: invert + flatten low values
      factor = v.rResid * 1.4;
    }
    // year scaling: 1979 = 0, 2025 = 1.0
    const yearF = (year - 1979) / 46;
    return base.map((row, ri) => row.map((cell, ci) => cell * factor * (0.4 + 0.6 * yearF)));
  }, [variable, mode, year]);

  const allVarOptions = ['T2m','T500','SPFH2m','PWAT','APCP','TCDC','DLWRF','ULWRF','DSWRF','USWRF','PRMSL','CSDSF','CSUSF','CSDLF','CSULF','CDUVB','DUVB','ALBDO'];

  const toggleBand = (b) => setActiveBands(s => s.includes(b) ? s.filter(x => x !== b) : [...s, b]);

  const variableMeta = allVars.find(v => v.var === variable);

  return (
    <section ref={ref} className="section" id="sec-3" data-screen-label="03 Earth 3D" style={{ minHeight: '120vh', padding: '96px 0 0', position: 'relative' }}>
      {/* Section header floating top */}
      <div style={{ padding: '0 56px 32px', position: 'relative', zIndex: 5 }}>
        <SectionHeader
          act="03"
          kicker="La carte du climat"
          title='Là où la <span class="text-hot">Terre se transforme</span>. <br/>Une variable, 47 ans, 18 fenêtres temporelles.'
          accent="var(--cold1)"
        />
      </div>

      {/* Big globe area */}
      <div style={{
        position: 'relative',
        width: '100%',
        height: '78vh',
        minHeight: 620,
        overflow: 'hidden',
      }}>
        <Globe
          grid={grid}
          autoRotate
          rotationSpeed={0.04}
          showTrend={1.0 * trendStrength}
          cameraDistance={bigDistance}
          hotspots={showHotspots ? hotspots : []}
          bands={activeBands}
          onHotspotClick={(hs) => setPicked(hs)}
          paused={!seen}
          segments={bigSegments}
          showGrid={tw.showGridLines !== false}
          showAtmosphere={tw.atmosphere !== false}
          showStars
          starCount={700}
        />

        {/* Floating control card — top right */}
        <div className="glass" style={{
          position: 'absolute', top: 28, right: 28,
          padding: 18, width: 280, zIndex: 4,
        }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 12 }}>
            Configuration
          </div>

          {/* Variable selector */}
          <div style={{ marginBottom: 14 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', marginBottom: 6 }}>Variable</div>
            <select
              value={variable}
              onChange={(e) => setVariable(e.target.value)}
              style={{
                width: '100%', padding: '8px 10px',
                background: 'rgba(255,255,255,0.04)',
                color: 'var(--text)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 6,
                fontFamily: 'JetBrains Mono, monospace', fontSize: 12,
                outline: 'none', cursor: 'pointer',
              }}
            >
              {allVarOptions.map(v => {
                const meta = allVars.find(x => x.var === v);
                return <option key={v} value={v}>{v} — {meta ? meta.name : v}</option>;
              })}
            </select>
          </div>

          {/* Mode toggle */}
          <div style={{ marginBottom: 14 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', marginBottom: 6 }}>Représentation</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
              <button className={`btn-glass ${mode === 'sen' ? 'active' : ''}`} onClick={() => setMode('sen')}>Tendance Sen</button>
              <button className={`btn-glass ${mode === 'corr' ? 'active' : ''}`} onClick={() => setMode('corr')}>Corr. CO₂</button>
            </div>
          </div>

          {/* Year slider */}
          <div style={{ marginBottom: 14 }}>
            <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 4 }}>
              <span className="mono" style={{ fontSize: 10, color: 'var(--text-dim)' }}>Période 1979 →</span>
              <span className="mono tabular" style={{ fontSize: 12, color: 'var(--hot1)' }}>{year}</span>
            </div>
            <input type="range" min="1985" max="2025" value={year} onChange={(e) => setYear(+e.target.value)}
              style={{ width: '100%', accentColor: 'var(--hot1)' }} />
          </div>

          {/* Bands */}
          <div style={{ marginBottom: 14 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)', marginBottom: 6 }}>Bandes de latitude</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {['austral','temperate_S','tropical','temperate_N','boreal'].map(b => (
                <button key={b} className={`btn-glass ${activeBands.includes(b) ? 'active' : ''}`} onClick={() => toggleBand(b)}
                  style={{ fontSize: 10, padding: '4px 8px' }}>
                  {b.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Hotspots toggle */}
          <div className="hstack" style={{ justifyContent: 'space-between' }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-dim)' }}>Hotspots</div>
            <button onClick={() => setShowHotspots(s => !s)}
              className={`btn-glass ${showHotspots ? 'active' : ''}`}
              style={{ fontSize: 10, padding: '4px 12px' }}>
              {showHotspots ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Variable info card — top left */}
        <div className="glass" style={{
          position: 'absolute', top: 28, left: 28,
          padding: 18, width: 280, zIndex: 4,
        }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 8 }}>
            Variable affichée
          </div>
          <div className="display" style={{ fontSize: 26, color: 'var(--text)', marginBottom: 4 }}>{variable}</div>
          <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 12 }}>{variableMeta?.name}</div>
          <div className="divider" style={{ margin: '12px 0' }} />
          <div className="hstack" style={{ justifyContent: 'space-between', fontSize: 11, marginBottom: 6 }}>
            <span className="text-dim mono">r résidus</span>
            <span className="mono tabular" style={{ color: variableMeta?.rResid > 0 ? 'var(--hot1)' : 'var(--cold1)' }}>
              {variableMeta?.rResid.toFixed(3)}
            </span>
          </div>
          <div className="hstack" style={{ justifyContent: 'space-between', fontSize: 11, marginBottom: 6 }}>
            <span className="text-dim mono">unité</span>
            <span className="mono tabular text-dim">{variableMeta?.unit}</span>
          </div>
          <div className="hstack" style={{ justifyContent: 'space-between', alignItems: 'center', fontSize: 11 }}>
            <span className="text-dim mono">causalité</span>
            <SensPill sens={variableMeta?.sens} />
          </div>
        </div>

        {/* Colormap legend — bottom right */}
        <div className="glass" style={{
          position: 'absolute', bottom: 28, right: 28,
          padding: '14px 18px', zIndex: 4,
        }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 8 }}>
            {mode === 'sen' ? 'Pente Sen (K/an)' : 'Corrélation avec CO₂'}
          </div>
          <div style={{
            width: 220, height: 12, borderRadius: 6,
            background: 'linear-gradient(to right, #00D9FF, #4dabff, #f0f0f0, #FFB627, #FF6B35)',
          }} />
          <div className="hstack" style={{ justifyContent: 'space-between', marginTop: 4, fontSize: 10, fontFamily: 'JetBrains Mono', color: 'var(--text-dim)' }}>
            <span>{mode === 'sen' ? '-0.06' : '-1.0'}</span>
            <span>0</span>
            <span>{mode === 'sen' ? '+0.11' : '+1.0'}</span>
          </div>
        </div>

        {/* Drag hint — bottom left */}
        <div style={{
          position: 'absolute', bottom: 28, left: 28, zIndex: 4,
          fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: '0.14em',
          color: 'var(--text-dim)', textTransform: 'uppercase',
        }}>
          <span style={{ opacity: 0.7 }}>↻ Glissez pour faire pivoter · cliquez un hotspot</span>
        </div>
      </div>

      {/* Drawer — hotspot detail */}
      <div className={`drawer ${picked ? 'open' : ''}`}>
        {picked && (
          <div>
            <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 20 }}>
              <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase' }}>
                Hotspot · {picked.label}
              </div>
              <button onClick={() => setPicked(null)} style={{
                background: 'none', border: 'none', color: 'var(--text-dim)',
                fontSize: 18, cursor: 'pointer', padding: 4,
              }}>×</button>
            </div>
            <div className="display" style={{ fontSize: 40, color: picked.color, marginBottom: 6 }}>{picked.name}</div>
            <div style={{ fontSize: 13, color: 'var(--text-dim)', marginBottom: 24 }}>{picked.role}</div>

            <div className="divider" style={{ margin: '12px 0 20px' }} />

            <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 12 }}>
              Tendances Sen & corrélation CO₂
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {Object.entries(picked.vars).map(([k, v]) => (
                <div key={k} style={{ padding: 14, background: 'rgba(255,255,255,0.03)', borderRadius: 8, border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="hstack" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                    <span className="mono" style={{ fontSize: 11, fontWeight: 600, color: 'var(--text)' }}>{k}</span>
                    <span className="mono tabular" style={{ fontSize: 10, color: v.mkP < 0.05 ? picked.color : 'var(--text-dim)' }}>
                      p={v.mkP.toFixed(3)}
                    </span>
                  </div>
                  <div className="hstack" style={{ gap: 16, fontSize: 11 }}>
                    <div>
                      <div className="mono text-dim" style={{ fontSize: 9 }}>Sen /an</div>
                      <div className="mono tabular" style={{ color: v.sen > 0 ? 'var(--hot1)' : 'var(--cold1)' }}>{v.sen > 0 ? '+' : ''}{v.sen.toFixed(4)}</div>
                    </div>
                    <div>
                      <div className="mono text-dim" style={{ fontSize: 9 }}>r résidu CO₂</div>
                      <div className="mono tabular" style={{ color: 'var(--text)' }}>{v.rCO2 > 0 ? '+' : ''}{v.rCO2.toFixed(3)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="divider" style={{ margin: '20px 0' }} />
            <div className="hstack" style={{ gap: 18 }}>
              <div>
                <div className="mono text-dim" style={{ fontSize: 10, letterSpacing: '0.1em' }}>GRANGER X→CO₂</div>
                <div className="display tabular" style={{ fontSize: 28, color: picked.color }}>{picked.grangerXtoCO2}<span className="mono" style={{ fontSize: 14, color: 'var(--text-dim)' }}>/4</span></div>
              </div>
              <div>
                <div className="mono text-dim" style={{ fontSize: 10, letterSpacing: '0.1em' }}>R² CO₂</div>
                <div className="display tabular" style={{ fontSize: 28, color: 'var(--text)' }}>{picked.R2.toFixed(3)}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

window.Earth3D = Earth3D;
