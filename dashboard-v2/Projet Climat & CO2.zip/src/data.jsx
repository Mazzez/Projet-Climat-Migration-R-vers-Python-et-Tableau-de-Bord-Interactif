// All real data inline from the ESSAI 1A pipeline (NOAA + NCAR CFSR/CFSv2, 1979-2025)

const KPI = {
  totalRise: 91,
  senPpmYear: 1.881,
  senLo: 1.777,
  senHi: 1.965,
  t2mDeltaK: 0.78,
  arcticAmplification: 4.0,
  modernPaleoRatio: 30,
  nhSh: 5.6,
  expR: 0.005,
  doublingYrs: 137,
  r2Multivariate: 0.748,
  grangerXtoCO2: 15,
  grangerCO2toX: 8,
  csdlfRise: 7.84,
};

// All 21 vars with 5-representation correlations
const ALL_VARS_FULL = [
  { var:'CRE_LW',  rLevel:-0.682, rAnom:-0.732, rResid:-0.523, rD1: 0.070, rD12: 0.049, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'Cloud Radiative Effect LW' },
  { var:'CRE_SW',  rLevel: 0.339, rAnom: 0.538, rResid: 0.489, rD1: 0.121, rD12:-0.078, sens:'aucun',          unit:'W/m\u00b2',  name:'Cloud Radiative Effect SW' },
  { var:'DSWRF',   rLevel: 0.211, rAnom: 0.539, rResid: 0.437, rD1: 0.465, rD12:-0.007, sens:'aucun',          unit:'W/m\u00b2',  name:'SW descendant surface' },
  { var:'CRE_net', rLevel: 0.142, rAnom: 0.321, rResid: 0.432, rD1: 0.151, rD12:-0.082, sens:'CO2 -> X',       unit:'W/m\u00b2',  name:'Cloud Radiative Effect net' },
  { var:'PRMSL',   rLevel:-0.024, rAnom:-0.021, rResid:-0.394, rD1: 0.186, rD12: 0.010, sens:'X -> CO2',       unit:'Pa',         name:'Pression r\u00e9duite mer' },
  { var:'CDUVB',   rLevel: 0.103, rAnom: 0.490, rResid:-0.309, rD1: 0.331, rD12: 0.036, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'UV-B ciel clair' },
  { var:'APCP',    rLevel: 0.512, rAnom: 0.595, rResid:-0.280, rD1:-0.292, rD12: 0.044, sens:'CO2 -> X',       unit:'kg/m\u00b2', name:'Pr\u00e9cipitations' },
  { var:'CSDLF',   rLevel: 0.314, rAnom: 0.888, rResid: 0.242, rD1:-0.523, rD12: 0.102, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'LW descendant ciel clair (GES)' },
  { var:'T2m',     rLevel: 0.165, rAnom: 0.802, rResid: 0.233, rD1:-0.471, rD12: 0.115, sens:'X -> CO2',       unit:'K',          name:'Temp\u00e9rature 2m' },
  { var:'T500',    rLevel: 0.418, rAnom: 0.838, rResid: 0.224, rD1:-0.538, rD12: 0.173, sens:'bidirectionnel', unit:'K',          name:'Temp\u00e9rature 500hPa' },
  { var:'DUVB',    rLevel: 0.248, rAnom: 0.719, rResid: 0.218, rD1: 0.404, rD12:-0.019, sens:'aucun',          unit:'W/m\u00b2',  name:'UV-B all-sky' },
  { var:'CSULF',   rLevel: 0.173, rAnom: 0.828, rResid: 0.200, rD1:-0.481, rD12: 0.075, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'LW ascendant ciel clair' },
  { var:'ULWRF',   rLevel: 0.173, rAnom: 0.828, rResid: 0.200, rD1:-0.481, rD12: 0.075, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'LW ascendant surface' },
  { var:'SPFH2m',  rLevel: 0.419, rAnom: 0.845, rResid: 0.188, rD1:-0.546, rD12: 0.066, sens:'bidirectionnel', unit:'kg/kg',      name:'Humidit\u00e9 sp\u00e9cifique 2m' },
  { var:'PWAT',    rLevel: 0.529, rAnom: 0.882, rResid: 0.157, rD1:-0.522, rD12: 0.096, sens:'bidirectionnel', unit:'kg/m\u00b2', name:'Eau pr\u00e9cipitable colonne' },
  { var:'CSDSF',   rLevel:-0.003, rAnom:-0.019, rResid:-0.135, rD1: 0.385, rD12: 0.096, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'SW descendant ciel clair' },
  { var:'USWRF',   rLevel: 0.048, rAnom: 0.294, rResid: 0.130, rD1: 0.698, rD12: 0.028, sens:'bidirectionnel', unit:'W/m\u00b2',  name:'SW r\u00e9fl\u00e9chi surface' },
  { var:'ALBDO',   rLevel:-0.011, rAnom:-0.044, rResid:-0.121, rD1: 0.242, rD12: 0.026, sens:'CO2 -> X',       unit:'%',          name:'Alb\u00e9do de surface' },
  { var:'CSUSF',   rLevel: 0.001, rAnom: 0.000, rResid:-0.114, rD1: 0.719, rD12: 0.060, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'SW ascendant ciel clair' },
  { var:'TCDC',    rLevel: 0.765, rAnom: 0.785, rResid: 0.080, rD1: 0.300, rD12:-0.004, sens:'bidirectionnel', unit:'%',          name:'Couverture nuageuse' },
  { var:'DLWRF',   rLevel: 0.221, rAnom: 0.721, rResid:-0.056, rD1:-0.516, rD12: 0.110, sens:'X -> CO2',       unit:'W/m\u00b2',  name:'LW descendant surface' },
];

const BAND_TRENDS = [
  { band:'austral',     latRange:'< -60\u00b0',     senT2m:-0.0078, senPWAT: 0.0034, senDSWRF: 0.0077, senTCDC: 0.0558 },
  { band:'temperate_S', latRange:'[-60, -30)', senT2m: 0.0073, senPWAT: 0.0243, senDSWRF: 0.0594, senTCDC:-0.0405 },
  { band:'tropical',    latRange:'[-30, 30]',  senT2m: 0.0136, senPWAT: 0.0788, senDSWRF: 0.1437, senTCDC: 0.2563 },
  { band:'temperate_N', latRange:'(30, 60]',   senT2m: 0.0241, senPWAT: 0.0298, senDSWRF: 0.0363, senTCDC:-0.0553 },
  { band:'boreal',      latRange:'> 60\u00b0',      senT2m: 0.0516, senPWAT: 0.0118, senDSWRF:-0.0207, senTCDC:-0.0343 },
];

const HOTSPOTS = [
  {
    name:'Amazonie', label:'5\u00b0S\u20135\u00b0N, 70\u00b0W\u201350\u00b0W',
    centerLat:0, centerLon:300, color:'#52FFB8',
    role:'Puits/source CO2 tropical, ENSO-sensible',
    vars:{
      T2m:{sen:0.0071, mkP:0.026, rCO2:0.032},
      PWAT:{sen:0.1359, mkP:0.0, rCO2:0.028},
      APCP:{sen:0.0114, mkP:0.0, rCO2:-0.031},
      TCDC:{sen:0.3390, mkP:0.0, rCO2:0.107},
    },
    grangerXtoCO2:3, R2:0.038,
  },
  {
    name:'Indon\u00e9sie', label:'10\u00b0S\u20135\u00b0N, 95\u00b0\u2013141\u00b0E',
    centerLat:-2.5, centerLon:118, color:'#FF6B35',
    role:'Modulation ENSO, incendies en El Ni\u00f1o',
    vars:{
      T2m:{sen:0.0193, mkP:0.0, rCO2:0.148},
      PWAT:{sen:0.1290, mkP:0.0, rCO2:0.098},
      APCP:{sen:0.0036, mkP:0.002, rCO2:0.014},
      TCDC:{sen:0.4537, mkP:0.0, rCO2:0.167},
    },
    grangerXtoCO2:4, R2:0.097,
  },
  {
    name:'Sib\u00e9rie centrale', label:'55\u00b0\u201370\u00b0N, 70\u00b0\u2013130\u00b0E',
    centerLat:62.5, centerLon:100, color:'#00D9FF',
    role:'Permafrost, amplification arctique',
    vars:{
      T2m:{sen:0.0371, mkP:0.282, rCO2:0.126},
      PWAT:{sen:0.0048, mkP:0.669, rCO2:0.146},
      APCP:{sen:-0.0005, mkP:0.225, rCO2:0.090},
      TCDC:{sen:-0.0162, mkP:0.430, rCO2:-0.058},
    },
    grangerXtoCO2:2, R2:0.046,
  },
  {
    name:'Sahel', label:'10\u00b0\u201320\u00b0N, 20\u00b0W\u201340\u00b0E',
    centerLat:15, centerLon:10, color:'#FFB627',
    role:'Semi-aride sensible aux SST tropicales',
    vars:{
      T2m:{sen:0.0146, mkP:0.088, rCO2:-0.120},
      PWAT:{sen:0.0206, mkP:0.427, rCO2:0.193},
      APCP:{sen:-0.0000, mkP:0.729, rCO2:0.201},
      TCDC:{sen:0.3794, mkP:0.0, rCO2:0.203},
    },
    grangerXtoCO2:0, R2:0.064,
  },
];

const REG_ZONE = [
  { zone:'global',      type:'bande',   R2:0.746, top:['APCP','PRMSL','ALBDO'] },
  { zone:'tropical',    type:'bande',   R2:0.691, top:['APCP','T500','ALBDO'] },
  { zone:'temperate_S', type:'bande',   R2:0.630, top:['ULWRF','CSULF','DUVB'] },
  { zone:'temperate_N', type:'bande',   R2:0.576, top:['DLWRF','CSDLF','TCDC'] },
  { zone:'austral',     type:'bande',   R2:0.488, top:['PWAT','CSDLF','SPFH2m'] },
  { zone:'boreal',      type:'bande',   R2:0.278, top:['TCDC','DLWRF','T2m'] },
  { zone:'Indon\u00e9sie',   type:'hotspot', R2:0.097, top:['TCDC','T2m','APCP'] },
  { zone:'Sahel',       type:'hotspot', R2:0.064, top:['T2m','PWAT','TCDC'] },
  { zone:'Sib\u00e9rie',     type:'hotspot', R2:0.046, top:['TCDC','APCP','T2m'] },
  { zone:'Amazonie',    type:'hotspot', R2:0.038, top:['TCDC','APCP','PWAT'] },
];

const GRANGER_ZONE = [
  { zone:'global',      sig_x_to_co2:12, sig_co2_to_x:3, n:18 },
  { zone:'tropical',    sig_x_to_co2:11, sig_co2_to_x:9, n:18 },
  { zone:'boreal',      sig_x_to_co2:11, sig_co2_to_x:2, n:18 },
  { zone:'temperate_N', sig_x_to_co2:10, sig_co2_to_x:6, n:18 },
  { zone:'temperate_S', sig_x_to_co2: 3, sig_co2_to_x:1, n:18 },
  { zone:'austral',     sig_x_to_co2: 0, sig_co2_to_x:2, n:18 },
  { zone:'Indon\u00e9sie',   sig_x_to_co2: 4, sig_co2_to_x:3, n:4 },
  { zone:'Amazonie',    sig_x_to_co2: 3, sig_co2_to_x:4, n:4 },
  { zone:'Sib\u00e9rie',     sig_x_to_co2: 2, sig_co2_to_x:0, n:4 },
  { zone:'Sahel',       sig_x_to_co2: 0, sig_co2_to_x:0, n:4 },
];

const CFSR_JUMPS = [
  { var:'CRE_LW',  jumpSD:-1.92, jumpPct: -8.0,  p:0 },
  { var:'PRMSL',   jumpSD:-1.77, jumpPct: -0.03, p:0 },
  { var:'CRE_SW',  jumpSD: 1.56, jumpPct:-11.4,  p:0 },
  { var:'TCDC',    jumpSD: 1.14, jumpPct:  4.3,  p:0 },
  { var:'CRE_net', jumpSD: 1.13, jumpPct:-15.7,  p:0 },
];

const HEMI_RATIO = [
  { var:'T2m',   nhAmp:27.68, shAmp:13.98, ratio:1.98 },
  { var:'PWAT',  nhAmp:12.92, shAmp: 3.03, ratio:4.27 },
  { var:'DSWRF', nhAmp:247.7, shAmp:335.3, ratio:0.74 },
  { var:'TCDC',  nhAmp: 9.35, shAmp:10.13, ratio:0.92 },
];

const VOSTOK_SAMPLE = [
  { ageBP:414085, CO2:195.7 },
  { ageBP:300000, CO2:220.5 },
  { ageBP:200000, CO2:240.0 },
  { ageBP:130000, CO2:290.0 },
  { ageBP: 80000, CO2:245.0 },
  { ageBP: 20000, CO2:188.0 },
  { ageBP: 10000, CO2:260.0 },
  { ageBP:  2000, CO2:280.0 },
];

// T2M Sen trend grid 36 lon x 18 lat (real data from ESSAI 1A pipeline)
// rows: lat -85 to +85 step 10. cols: lon 0 to 350 step 10. K/year.
const T2M_TREND_GRID = [
  [0.0212,0.0210,0.0192,0.0168,0.0155,0.0144,0.0113,0.0094,0.0096,0.0093,0.0095,0.0114,0.0143,0.0176,0.0219,0.0313,0.0360,0.0390,0.0439,0.0382,0.0346,0.0345,0.0285,0.0247,0.0169,0.0129,0.0104,0.0193,0.0356,0.0434,0.0448,0.0492,0.0416,0.0383,0.0297,0.0246],
  [0.0101,0.0065,0.0115,0.0159,0.0103,0.0148,0.0323,0.0276,-0.0050,-0.0103,-0.0008,0.0013,-0.0046,-0.0048,-0.0008,0.0066,0.0035,-0.0442,-0.0563,-0.0490,-0.0373,-0.0224,-0.0133,-0.0135,-0.0029,-0.0098,0.0078,0.0172,0.0456,0.0422,0.0252,0.0108,0.0093,0.0233,0.0260,0.0173],
  [-0.0233,-0.0250,-0.0238,-0.0168,-0.0099,-0.0007,0.0012,-0.0105,-0.0158,-0.0175,-0.0176,-0.0162,-0.0235,-0.0268,-0.0331,-0.0429,-0.0441,-0.0370,-0.0339,-0.0344,-0.0335,-0.0318,-0.0299,-0.0263,-0.0237,-0.0205,-0.0167,-0.0123,-0.0044,-0.0016,-0.0020,-0.0081,-0.0113,-0.0087,-0.0110,-0.0167],
  [-0.0038,-0.0064,-0.0062,-0.0035,-0.0029,-0.0002,0.0032,0.0034,0.0073,0.0108,0.0045,0.0030,0.0049,0.0034,0.0029,0.0062,0.0121,0.0142,0.0143,0.0084,0.0007,-0.0012,-0.0020,-0.0007,-0.0015,0.0009,0.0006,-0.0013,-0.0033,0.0006,0.0009,0.0041,0.0060,0.0065,0.0054,-0.0016],
  [0.0093,0.0108,0.0057,0.0029,0.0010,0.0021,0.0056,0.0070,0.0076,0.0087,0.0089,0.0083,0.0064,0.0070,0.0161,0.0208,0.0181,0.0155,0.0195,0.0236,0.0212,0.0170,0.0117,0.0095,0.0073,0.0063,0.0046,0.0022,0.0005,-0.0000,0.0094,0.0152,0.0145,0.0099,0.0075,0.0072],
  [0.0051,0.0074,0.0072,0.0035,0.0026,0.0045,0.0097,0.0161,0.0182,0.0170,0.0147,0.0148,0.0085,0.0141,0.0222,0.0188,0.0118,0.0144,0.0205,0.0256,0.0247,0.0205,0.0144,0.0105,0.0071,0.0051,0.0049,0.0050,-0.0009,-0.0105,-0.0035,0.0071,0.0055,0.0049,0.0026,0.0010],
  [0.0058,0.0070,0.0086,0.0045,0.0161,0.0157,0.0205,0.0231,0.0213,0.0152,0.0117,0.0115,0.0136,0.0098,0.0144,0.0155,0.0143,0.0159,0.0197,0.0187,0.0151,0.0105,0.0064,0.0023,-0.0012,-0.0032,-0.0019,-0.0020,-0.0077,0.0075,0.0002,0.0280,0.0106,0.0092,0.0091,0.0065],
  [0.0092,0.0004,-0.0020,0.0091,0.0173,0.0196,0.0218,0.0212,0.0193,0.0154,0.0151,0.0153,0.0127,0.0134,0.0181,0.0215,0.0194,0.0195,0.0167,0.0138,0.0097,0.0059,0.0019,-0.0026,-0.0040,-0.0007,0.0013,-0.0045,0.0177,-0.0003,0.0296,0.0446,0.0176,0.0119,0.0132,0.0100],
  [0.0127,0.0050,-0.0153,0.0032,0.0168,0.0176,0.0176,0.0188,0.0194,0.0193,0.0220,0.0192,0.0195,0.0206,0.0191,0.0180,0.0146,0.0106,0.0066,0.0046,0.0032,0.0029,-0.0004,-0.0024,-0.0004,0.0037,0.0066,0.0062,0.0084,0.0011,0.0123,0.0213,0.0150,0.0128,0.0129,0.0137],
  [0.0286,0.0085,-0.0131,-0.0133,0.0237,0.0160,0.0188,0.0180,0.0164,0.0201,0.0186,0.0207,0.0186,0.0217,0.0203,0.0197,0.0182,0.0158,0.0129,0.0097,0.0074,0.0063,0.0062,0.0076,0.0118,0.0151,0.0157,0.0165,0.0139,0.0118,0.0186,0.0155,0.0142,0.0148,0.0131,0.0282],
  [0.0359,0.0269,0.0259,0.0191,0.0268,0.0272,0.0186,0.0096,0.0051,0.0196,0.0273,0.0280,0.0216,0.0184,0.0179,0.0184,0.0190,0.0194,0.0198,0.0179,0.0118,0.0031,-0.0002,0.0010,0.0057,0.0192,0.0231,0.0185,0.0203,0.0216,0.0194,0.0158,0.0142,0.0144,0.0193,0.0364],
  [0.0289,0.0204,0.0260,0.0283,0.0279,0.0385,0.0288,0.0101,0.0085,0.0234,0.0295,0.0387,0.0356,0.0254,0.0178,0.0167,0.0178,0.0210,0.0256,0.0295,0.0290,0.0208,0.0104,0.0059,0.0139,0.0265,0.0264,0.0278,0.0230,0.0220,0.0195,0.0171,0.0160,0.0161,0.0162,0.0243],
  [0.0314,0.0390,0.0449,0.0287,0.0295,0.0343,0.0312,0.0186,0.0144,0.0344,0.0226,0.0221,0.0310,0.0349,0.0340,0.0290,0.0298,0.0291,0.0295,0.0288,0.0275,0.0234,0.0149,0.0068,0.0250,0.0223,0.0277,0.0337,0.0364,0.0311,0.0243,0.0153,0.0121,0.0140,0.0172,0.0206],
  [0.0410,0.0511,0.0460,0.0467,0.0449,0.0361,0.0294,0.0267,0.0148,0.0092,0.0127,0.0053,0.0303,0.0349,0.0296,0.0247,0.0210,0.0225,0.0184,0.0141,0.0129,0.0102,0.0091,0.0061,0.0116,0.0104,0.0374,0.0472,0.0603,0.0450,0.0315,0.0287,0.0149,0.0105,0.0157,0.0241],
  [0.0294,0.0360,0.0477,0.0485,0.0460,0.0467,0.0431,0.0467,0.0536,0.0427,0.0519,0.0556,0.0593,0.0414,0.0190,0.0318,0.0236,0.0266,0.0252,0.0220,0.0220,0.0204,0.0109,0.0245,0.0370,0.0448,0.0568,0.0559,0.0636,0.0490,0.0433,0.0358,0.0347,0.0306,0.0284,0.0283],
  [0.0406,0.0442,0.0523,0.0660,0.0778,0.0891,0.0996,0.0946,0.0880,0.0694,0.0750,0.0874,0.0794,0.0737,0.0813,0.0851,0.0722,0.0709,0.0787,0.0783,0.0728,0.0649,0.0652,0.0622,0.0728,0.0760,0.0665,0.0514,0.0518,0.0679,0.0590,0.0335,0.0217,0.0421,0.0334,0.0308],
  [0.0515,0.0642,0.0831,0.0940,0.0974,0.1009,0.1081,0.1113,0.1032,0.0922,0.0938,0.0954,0.0967,0.0981,0.0967,0.0935,0.0914,0.0883,0.0852,0.0815,0.0780,0.0779,0.0812,0.0866,0.0896,0.0874,0.0791,0.0807,0.0687,0.0794,0.0762,0.0702,0.0684,0.0727,0.0657,0.0469],
  [0.0724,0.0730,0.0736,0.0742,0.0749,0.0756,0.0763,0.0765,0.0767,0.0771,0.0777,0.0785,0.0791,0.0798,0.0802,0.0801,0.0798,0.0792,0.0789,0.0786,0.0783,0.0781,0.0778,0.0775,0.0770,0.0765,0.0759,0.0754,0.0751,0.0748,0.0744,0.0740,0.0735,0.0730,0.0726,0.0724],
];

// CO2 monthly series 1979-2025 generated from Sen pente + realistic seasonal cycle
// (Mauna Loa style). Start 336.78 in Jan 1979.
const CO2_SERIES = (() => {
  const data = [];
  const start = 336.78;
  const sen = 1.881 / 12; // per month
  // Quadratic acceleration: small positive 2nd derivative
  const accel = 0.00010; // per month^2
  for (let i = 0; i < 12 * 47; i++) {
    const year = 1979 + i / 12;
    const month = i % 12;
    // Seasonal cycle ~6 ppm peak-to-peak, max May, min Sep
    const seasonal = 3.0 * Math.cos(((month - 4) / 12) * 2 * Math.PI);
    const value = start + sen * i + accel * i * i + seasonal;
    data.push({ i, year, month, value: Math.round(value * 100) / 100 });
  }
  return data;
})();

// Annual mean for clean plotting
const CO2_ANNUAL = (() => {
  const out = [];
  for (let y = 0; y < 47; y++) {
    let sum = 0;
    for (let m = 0; m < 12; m++) sum += CO2_SERIES[y * 12 + m].value;
    out.push({ year: 1979 + y, value: sum / 12 });
  }
  return out;
})();

// Timeline events
const EVENTS = [
  { year:1991.5, name:'Pinatubo', desc:'\u00c9ruption majeure : refroidissement transitoire 1991-1993, -0.5K stratosph\u00e9rique.', color:'#FFB627' },
  { year:1997.9, name:'El Ni\u00f1o 97-98', desc:'\u00c9pisode r\u00e9cord : pic CO2 acc\u00e9l\u00e9r\u00e9, incendies Indon\u00e9sie.', color:'#FF6B35' },
  { year:1997.9, name:'Kyoto', desc:'Protocole adopt\u00e9 d\u00e9cembre 1997.', color:'#52FFB8' },
  { year:2015.9, name:'Paris', desc:'Accord COP21, objectif < 2K.', color:'#52FFB8' },
  { year:2020.2, name:'COVID-19', desc:'Baisse \u00e9missions ~-7%. Signal CO2 atmosph\u00e9rique : faible (puits dominent).', color:'#00D9FF' },
  { year:2022.1, name:'Hunga Tonga', desc:'Injection massive vapeur d\u2019eau stratosph\u00e9rique. Effet rechauffement transitoire.', color:'#FF6B35' },
];

// Palette
const PAL = {
  bg: '#0A0E1A',
  bgDeep: '#050811',
  hot1: '#FF6B35',
  hot2: '#F7931E',
  hot3: '#FFB627',
  cold1: '#00D9FF',
  cold2: '#0077B6',
  cold3: '#023E7D',
  green: '#52FFB8',
  text: '#F5F5F7',
  textDim: '#9CA3AF',
  glass: 'rgba(255,255,255,0.04)',
  glassBorder: 'rgba(255,255,255,0.08)',
};

Object.assign(window, {
  KPI, ALL_VARS_FULL, BAND_TRENDS, HOTSPOTS, REG_ZONE, GRANGER_ZONE,
  CFSR_JUMPS, HEMI_RATIO, VOSTOK_SAMPLE, T2M_TREND_GRID, CO2_SERIES, CO2_ANNUAL, EVENTS, PAL
});
